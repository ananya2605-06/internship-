"""
Malware Detection Module - Feature Extraction
Extracts static features from PE files for malware classification
"""

import pefile
import numpy as np
import math
import re
import logging
from pathlib import Path
from typing import Dict, List, Optional
import hashlib

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class PEFeatureExtractor:
    """
    Extracts static analysis features from Windows PE files
    """
    
    def __init__(self):
        self.feature_names = []
        self._initialize_feature_names()
    
    def _initialize_feature_names(self):
        """Define all feature names for consistent ordering"""
        # General features (10)
        self.feature_names.extend([
            'file_size', 'virtual_size', 'has_debug', 'has_relocations',
            'has_resources', 'has_signature', 'has_tls', 'has_imports',
            'has_exports', 'num_sections'
        ])
        
        # Section features (30) - 6 features per section, up to 5 sections
        for i in range(5):
            self.feature_names.extend([
                f'section_{i}_size', f'section_{i}_virtual_size',
                f'section_{i}_entropy', f'section_{i}_suspicious_name',
                f'section_{i}_executable', f'section_{i}_writable'
            ])
        
        # Import/Export features (14)
        self.feature_names.extend([
            'num_imports', 'num_imported_dlls', 'num_exports',
            'imports_kernel32', 'imports_user32', 'imports_advapi32',
            'imports_ws2_32', 'imports_wininet', 'imports_ntdll',
            'suspicious_imports_count', 'has_createprocess',
            'has_virtualallocex', 'has_writeprocessmemory', 'has_createremotethread'
        ])
        
        # String features (10)
        self.feature_names.extend([
            'num_strings', 'avg_string_length', 'max_string_length',
            'string_entropy', 'has_url', 'has_ip', 'has_registry',
            'has_file_path', 'suspicious_strings_count', 'printable_ratio'
        ])
        
        # Byte histogram (256)
        self.feature_names.extend([f'byte_{i:02x}' for i in range(256)])
        
        # Entropy (1)
        self.feature_names.append('file_entropy')
        
        logger.info(f"Initialized {len(self.feature_names)} feature names")
    
    def extract_features(self, file_path: str) -> Dict:
        """
        Main extraction method - extracts all features from PE file
        
        Args:
            file_path: Path to PE file
            
        Returns:
            Dictionary of features
        """
        try:
            logger.info(f"Extracting features from {file_path}")
            
            # Read file bytes
            with open(file_path, 'rb') as f:
                file_bytes = f.read()
            
            # Parse PE
            pe = pefile.PE(file_path, fast_load=False)
            
            # Extract all feature categories
            features = {}
            features.update(self._extract_general_features(pe, file_bytes))
            features.update(self._extract_section_features(pe))
            features.update(self._extract_import_export_features(pe))
            features.update(self._extract_string_features(file_bytes))
            features.update(self._extract_byte_histogram(file_bytes))
            features.update(self._extract_entropy_features(file_bytes))
            
            # Calculate hash for identification
            features['sha256'] = hashlib.sha256(file_bytes).hexdigest()
            features['md5'] = hashlib.md5(file_bytes).hexdigest()
            
            pe.close()
            
            logger.info(f"Extracted {len(features)} features")
            return features
            
        except pefile.PEFormatError as e:
            logger.error(f"Invalid PE file {file_path}: {e}")
            raise ValueError(f"Not a valid PE file: {e}")
        except Exception as e:
            logger.error(f"Error extracting features from {file_path}: {e}")
            raise
    
    def _extract_general_features(self, pe: pefile.PE, file_bytes: bytes) -> Dict:
        """Extract general PE metadata"""
        features = {}
        
        features['file_size'] = len(file_bytes)
        features['virtual_size'] = pe.OPTIONAL_HEADER.SizeOfImage
        
        # Check various PE characteristics
        features['has_debug'] = hasattr(pe, 'DIRECTORY_ENTRY_DEBUG')
        features['has_relocations'] = hasattr(pe, 'DIRECTORY_ENTRY_BASERELOC')
        features['has_resources'] = hasattr(pe, 'DIRECTORY_ENTRY_RESOURCE')
        features['has_signature'] = hasattr(pe, 'DIRECTORY_ENTRY_SECURITY')
        features['has_tls'] = hasattr(pe, 'DIRECTORY_ENTRY_TLS')
        features['has_imports'] = hasattr(pe, 'DIRECTORY_ENTRY_IMPORT')
        features['has_exports'] = hasattr(pe, 'DIRECTORY_ENTRY_EXPORT')
        features['num_sections'] = pe.FILE_HEADER.NumberOfSections
        
        return {k: int(v) if isinstance(v, bool) else v for k, v in features.items()}
    
    def _extract_section_features(self, pe: pefile.PE) -> Dict:
        """Extract features from PE sections"""
        features = {}
        suspicious_section_names = {'.text', '.data', '.rdata', '.idata', '.rsrc'}
        
        for i in range(5):  # Handle up to 5 sections
            if i < len(pe.sections):
                section = pe.sections[i]
                
                # Get section data
                section_data = section.get_data()
                section_name = section.Name.decode('utf-8', errors='ignore').strip('\x00')
                
                features[f'section_{i}_size'] = section.SizeOfRawData
                features[f'section_{i}_virtual_size'] = section.Misc_VirtualSize
                features[f'section_{i}_entropy'] = self._calculate_entropy(section_data)
                features[f'section_{i}_suspicious_name'] = int(section_name not in suspicious_section_names)
                features[f'section_{i}_executable'] = int(section.Characteristics & 0x20000000 != 0)
                features[f'section_{i}_writable'] = int(section.Characteristics & 0x80000000 != 0)
            else:
                # Padding for missing sections
                features[f'section_{i}_size'] = 0
                features[f'section_{i}_virtual_size'] = 0
                features[f'section_{i}_entropy'] = 0
                features[f'section_{i}_suspicious_name'] = 0
                features[f'section_{i}_executable'] = 0
                features[f'section_{i}_writable'] = 0
        
        return features
    
    def _extract_import_export_features(self, pe: pefile.PE) -> Dict:
        """Extract import/export table features"""
        features = {}
        
        # Imports
        suspicious_apis = {
            'CreateProcess', 'VirtualAllocEx', 'WriteProcessMemory', 
            'CreateRemoteThread', 'LoadLibrary', 'GetProcAddress',
            'URLDownloadToFile', 'WinExec', 'ShellExecute'
        }
        
        important_dlls = ['kernel32.dll', 'user32.dll', 'advapi32.dll', 
                         'ws2_32.dll', 'wininet.dll', 'ntdll.dll']
        
        if hasattr(pe, 'DIRECTORY_ENTRY_IMPORT'):
            imports = []
            dll_counts = {dll: 0 for dll in important_dlls}
            suspicious_count = 0
            
            for entry in pe.DIRECTORY_ENTRY_IMPORT:
                dll_name = entry.dll.decode('utf-8', errors='ignore').lower()
                
                # Count important DLLs
                if dll_name in dll_counts:
                    dll_counts[dll_name] = 1
                
                for imp in entry.imports:
                    if imp.name:
                        func_name = imp.name.decode('utf-8', errors='ignore')
                        imports.append(func_name)
                        
                        # Check for suspicious APIs
                        if any(api.lower() in func_name.lower() for api in suspicious_apis):
                            suspicious_count += 1
            
            features['num_imports'] = len(imports)
            features['num_imported_dlls'] = len(pe.DIRECTORY_ENTRY_IMPORT)
            features['suspicious_imports_count'] = suspicious_count
            
            # Specific DLL checks
            features['imports_kernel32'] = dll_counts['kernel32.dll']
            features['imports_user32'] = dll_counts['user32.dll']
            features['imports_advapi32'] = dll_counts['advapi32.dll']
            features['imports_ws2_32'] = dll_counts['ws2_32.dll']
            features['imports_wininet'] = dll_counts['wininet.dll']
            features['imports_ntdll'] = dll_counts['ntdll.dll']
            
            # Specific API checks
            features['has_createprocess'] = int(any('CreateProcess' in i for i in imports))
            features['has_virtualallocex'] = int(any('VirtualAllocEx' in i for i in imports))
            features['has_writeprocessmemory'] = int(any('WriteProcessMemory' in i for i in imports))
            features['has_createremotethread'] = int(any('CreateRemoteThread' in i for i in imports))
        else:
            features['num_imports'] = 0
            features['num_imported_dlls'] = 0
            features['suspicious_imports_count'] = 0
            for dll in important_dlls:
                features[f"imports_{dll.replace('.dll', '').replace('_', '')}"] = 0
            features['has_createprocess'] = 0
            features['has_virtualallocex'] = 0
            features['has_writeprocessmemory'] = 0
            features['has_createremotethread'] = 0
        
        # Exports
        if hasattr(pe, 'DIRECTORY_ENTRY_EXPORT'):
            features['num_exports'] = len(pe.DIRECTORY_ENTRY_EXPORT.symbols)
        else:
            features['num_exports'] = 0
        
        return features
    
    def _extract_string_features(self, file_bytes: bytes) -> Dict:
        """Extract string-based features"""
        features = {}
        
        # Extract printable strings (length >= 4)
        strings = re.findall(b'[\x20-\x7E]{4,}', file_bytes)
        strings = [s.decode('utf-8', errors='ignore') for s in strings]
        
        if strings:
            features['num_strings'] = len(strings)
            features['avg_string_length'] = np.mean([len(s) for s in strings])
            features['max_string_length'] = max([len(s) for s in strings])
            
            # String entropy
            all_strings = ''.join(strings)
            features['string_entropy'] = self._calculate_entropy(all_strings.encode())
            
            # Pattern matching
            features['has_url'] = int(any(re.search(r'https?://', s) for s in strings))
            features['has_ip'] = int(any(re.search(r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}', s) for s in strings))
            features['has_registry'] = int(any('HKEY' in s or 'Registry' in s for s in strings))
            features['has_file_path'] = int(any(':\\' in s or '/' in s for s in strings))
            
            # Suspicious string patterns
            suspicious_patterns = [
                'cmd.exe', 'powershell', 'regedit', 'taskkill', 
                'netsh', 'sc.exe', 'schtasks', 'wmic'
            ]
            features['suspicious_strings_count'] = sum(
                1 for s in strings if any(pattern.lower() in s.lower() for pattern in suspicious_patterns)
            )
        else:
            features['num_strings'] = 0
            features['avg_string_length'] = 0
            features['max_string_length'] = 0
            features['string_entropy'] = 0
            features['has_url'] = 0
            features['has_ip'] = 0
            features['has_registry'] = 0
            features['has_file_path'] = 0
            features['suspicious_strings_count'] = 0
        
        # Printable character ratio
        printable_count = sum(1 for b in file_bytes if 32 <= b <= 126)
        features['printable_ratio'] = printable_count / len(file_bytes) if len(file_bytes) > 0 else 0
        
        return features
    
    def _extract_byte_histogram(self, file_bytes: bytes) -> Dict:
        """Extract byte frequency histogram (256 features)"""
        histogram = np.zeros(256)
        
        for byte in file_bytes:
            histogram[byte] += 1
        
        # Normalize by file size
        histogram = histogram / len(file_bytes) if len(file_bytes) > 0 else histogram
        
        return {f'byte_{i:02x}': histogram[i] for i in range(256)}
    
    def _extract_entropy_features(self, file_bytes: bytes) -> Dict:
        """Calculate file entropy"""
        return {'file_entropy': self._calculate_entropy(file_bytes)}
    
    def _calculate_entropy(self, data: bytes) -> float:
        """Calculate Shannon entropy"""
        if len(data) == 0:
            return 0.0
        
        # Count byte frequencies
        byte_counts = np.bincount(np.frombuffer(data, dtype=np.uint8), minlength=256)
        probabilities = byte_counts / len(data)
        
        # Remove zero probabilities
        probabilities = probabilities[probabilities > 0]
        
        # Calculate entropy
        entropy = -np.sum(probabilities * np.log2(probabilities))
        
        return float(entropy)
    
    def extract_to_vector(self, file_path: str) -> np.ndarray:
        """
        Extract features and return as ordered numpy array
        
        Args:
            file_path: Path to PE file
            
        Returns:
            Feature vector (numpy array)
        """
        features = self.extract_features(file_path)
        
        # Create vector in consistent order (excluding hash values)
        vector = []
        for name in self.feature_names:
            vector.append(features.get(name, 0))
        
        return np.array(vector, dtype=np.float64)


def batch_extract_features(file_paths: List[str], output_csv: str):
    """
    Extract features from multiple PE files and save to CSV
    
    Args:
        file_paths: List of PE file paths
        output_csv: Output CSV path
    """
    import pandas as pd
    
    extractor = PEFeatureExtractor()
    all_features = []
    
    for i, file_path in enumerate(file_paths):
        try:
            logger.info(f"Processing {i+1}/{len(file_paths)}: {file_path}")
            features = extractor.extract_features(file_path)
            features['file_path'] = file_path
            all_features.append(features)
        except Exception as e:
            logger.error(f"Failed to process {file_path}: {e}")
            continue
    
    # Save to CSV
    df = pd.DataFrame(all_features)
    df.to_csv(output_csv, index=False)
    logger.info(f"Saved {len(all_features)} feature sets to {output_csv}")


if __name__ == "__main__":
    print("PE Feature Extractor")
    print("="*50)
    
    # Example usage
    extractor = PEFeatureExtractor()
    print(f"Total features: {len(extractor.feature_names)}")
    print(f"Feature categories: General, Section, Import/Export, String, Byte Histogram, Entropy")
    
    # To extract from a file:
    # features = extractor.extract_features('path/to/sample.exe')
    # vector = extractor.extract_to_vector('path/to/sample.exe')
